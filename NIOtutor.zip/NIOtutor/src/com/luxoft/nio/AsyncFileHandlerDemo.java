package com.luxoft.nio;

import java.io.IOException;

import java.nio.ByteBuffer;

import java.nio.channels.AsynchronousFileChannel;
import java.nio.channels.CompletionHandler;

import java.nio.file.Path;
import java.nio.file.Paths;

public class AsyncFileHandlerDemo {

    public static void main(String[] args) throws Exception {
        Path path = Paths.get("file.txt");
        AsynchronousFileChannel ch = AsynchronousFileChannel.open(path);
        final ByteBuffer buf = ByteBuffer.allocate(1024);

        ch.read(buf, 0, null,
                new CompletionHandler<Integer, Void>() {
                    @Override
                    public void completed(Integer result, Void v) {
                        System.out.println("Bytes read = " + result);
                        System.out.println(new String(buf.array(),0,result));
                    }
                    @Override
                    public void failed(Throwable t, Void v) {
                        System.out.println("Failure: " + t.toString());
                    }
                });

        System.out.println("Continue with the next tasks...");
        try {
            Thread.sleep(100);
        } catch (InterruptedException ie) {
            System.out.println("Terminating");
        }

        ch.close();

    }
}