package com.luxoft.nio;

import java.io.IOException;

import java.nio.ByteBuffer;

import java.nio.channels.AsynchronousFileChannel;

import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.concurrent.Future;

public class AsyncFileChannelDemo {
    public static void main(String[] args) throws Exception {
        Path path = Paths.get("file.txt");
        try (AsynchronousFileChannel ch = AsynchronousFileChannel.open(path);) {
            ByteBuffer buf = ByteBuffer.allocate(1024);
            Future<Integer> result = ch.read(buf, 0); // non-blocking read
            while (!result.isDone()) {
                System.out.println("Sleeping...");
                //Thread.sleep(1);
            }
            System.out.println("Finished = " + result.isDone());
            System.out.println("Bytes read = " + result.get());
            // getting file contents
            byte[] data = buf.array();
            int length = result.get();
            String contents = new String(data, 0, length);
            System.out.println(contents);
        }
    }
}