package com.luxoft.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class SelectorServer1
{
    final static int DEFAULT_PORT = 9999;

    public static void main(String[] args) throws IOException {
        int port = DEFAULT_PORT;
        System.out.println("Server starting ... listening on port " + port);

        ServerSocketChannel ssc = ServerSocketChannel.open();
        ServerSocket ss = ssc.socket();
        ss.bind(new InetSocketAddress(port));
        ssc.configureBlocking(false);

        Selector s = Selector.open();
        ssc.register(s, SelectionKey.OP_ACCEPT);
        SocketChannel sc2 = null;

        while (true) {
            int n = s.select(); // selecting some channel
            if (n == 0) continue; // nothing was selected
            Iterator it = s.selectedKeys().iterator();
            while (it.hasNext()) {
                SelectionKey key = (SelectionKey) it.next();
                if (key.isAcceptable()) {
                    SocketChannel sc;
                    // non-blocking accept
                    sc = ((ServerSocketChannel) key.channel()).accept();
                    if (sc == null) continue; // no pending connections
                    System.out.println("Receiving connection");

                    // Make sure to make it non-blocking, so we can
                    // use a selector on it.
                    sc.configureBlocking( false );

                    // Register it with the selector, for reading
                    sc.register( s, SelectionKey.OP_WRITE);

                } else if (key.isWritable()) {
                    System.out.println("Writing hello");
                    sc2 = ((SocketChannel) key.channel());
                    String message = "hello from server";
                    ByteBuffer buf = ByteBuffer.wrap(message.getBytes());
                    sc2.write(buf);
                    //while (buf.hasRemaining()) sc2.write(buf);
                    sc2.close();
                }
                it.remove(); // remove if communication is done
            }
        }
    }
}