package com.luxoft.nio.netty;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

public class NettyClient {
    public static int PORT = NettyServer.PORT;
    public static String HOST = "localhost";

    public static void main(String[] args) throws Exception {
        EventLoopGroup workerGroup = new NioEventLoopGroup();

        try {
            // Bootstrap is similar to ServerBootstrap
            // except that it's for non-server channels
            // such as a client-side or connectionless channel.
            Bootstrap b = new Bootstrap();
            // The boss worker is not used for the client side.
            b.group(workerGroup);
            // Instead of NioServerSocketChannel, NioSocketChannel
            // is being used to create a client-side Channel.
            b.channel(NioSocketChannel.class);
            // Note that we do not use childOption() here
            // unlike we did with ServerBootstrap because
            // the client-side SocketChannel does not have a parent.
            b.option(ChannelOption.SO_KEEPALIVE, true);

            b.handler(new ChannelInitializer<SocketChannel>() {
                @Override
                public void initChannel(SocketChannel ch) throws Exception {
                    ch.pipeline().addLast(new NettyTimeClientHandler());
                }
            });

            // Start the client.
            ChannelFuture f = b.connect(HOST, PORT).sync();

            // Wait until the connection is closed.
            f.channel().closeFuture().sync();
        } finally {
            workerGroup.shutdownGracefully();
        }
    }
}


