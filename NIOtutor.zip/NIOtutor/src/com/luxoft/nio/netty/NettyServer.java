package com.luxoft.nio.netty;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;

public class NettyServer {
    public static int PORT = 8080;

    public static void main(String[] args) throws Exception {

        // NioEventLoopGroup is a multithreaded
        // event loop that handles I/O operation
        // We are implementing a server-side application in this example,
        // and therefore two NioEventLoopGroup will be used.
        // The first one, often called 'boss', accepts
        // an incoming connection.

        // The second one, often called 'worker',
        // handles the traffic of the accepted connection
        // once the boss accepts the connection
        // and registers the accepted connection to the worker.
        // How many Threads are used and how they are mapped
        // to the created Channels depends on the EventLoopGroup
        // implementation and may be even configurable via a constructor.

        EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workerGroup = new NioEventLoopGroup();

        try {
            // ServerBootstrap is a helper class that sets up a server.
            // You can set up the server using a Channel directly,
            // but it's more complicated and not recommended.
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup)
            //  NioServerSocketChannel class which is used to
            //  instantiate a new Channel to accept incoming connections
            .channel(NioServerSocketChannel.class)
            // The handler specified here will always be evaluated
            // by a newly accepted Channel
            .childHandler(new ChannelInitializer<SocketChannel>() {
                @Override
                public void initChannel(SocketChannel ch) throws Exception {
                    // As the application gets complicated,
                    // it is likely that you will add more handlers
                    // to the pipeline.
                    ch.pipeline().addLast(new NettyTimeServerHandler());
                }
            })
            // We are writing a TCP/IP server, so we are allowed
            // to set the socket options such as tcpNoDelay and keepAlive
            .option(ChannelOption.SO_BACKLOG, 128)
                // maximum number of connections queued
            .childOption(ChannelOption.SO_KEEPALIVE, true);
                // option() is for the NioServerSocketChannel
                // that accepts incoming connections.
                // childOption() is for the Channels
                // accepted by the parent ServerChannel

            // Bind and start to accept incoming connections.
            ChannelFuture f = b.bind(PORT).sync();
                // sync() makes operation synchronous

            // Wait until the server socket is closed.
            // In this example, this does not happen,
            // but you can do that to gracefully
            // shut down your server.
            f.channel().closeFuture().sync();
        } finally {
            workerGroup.shutdownGracefully();
            bossGroup.shutdownGracefully();
        }
    }
}