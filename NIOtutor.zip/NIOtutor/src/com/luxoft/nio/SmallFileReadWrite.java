package com.luxoft.nio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class SmallFileReadWrite {
    public static void main(String[] args) {
        Charset charset = Charset.forName("UTF-8");

        // writing to file
        Path file = Paths.get("file.txt");
        ArrayList<String> lines = new ArrayList<>();
        lines.add("Roses are red,");
        lines.add("Violets are blue,");
        lines.add("candy is sweet,");
        lines.add("And so are you.");

        try {
            Files.write(file, lines, charset, StandardOpenOption.CREATE);
        } catch (IOException e) {
            System.err.println(e);
        }

        // reading from file - bytes
        try {
            byte[] barray = Files.readAllBytes(file);
            System.out.println(barray.length);
        } catch (IOException e) {
            System.out.println(e);
        }

        // reading from file - lines
        try {
            List<String> lines2 = Files.readAllLines(file, charset);
            for (String line : lines2) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println(e);
        }

        // Buffered writer
        String text = "Hi there!";
        try (BufferedWriter writer = Files.newBufferedWriter(file, charset,
                StandardOpenOption.APPEND)) {
            writer.write(text);
        } catch (IOException e) {
            System.err.println(e);
        }

        // Buffered reader
        System.out.println("=== Buffered reader");
        try (BufferedReader reader = Files.newBufferedReader(file, charset)) {
            String line = null;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println(e);
        }

    }
}
