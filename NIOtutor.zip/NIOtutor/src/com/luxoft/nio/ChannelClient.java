package com.luxoft.nio;

import java.io.IOException;

import java.net.InetSocketAddress;

import java.nio.ByteBuffer;

import java.nio.channels.SocketChannel;

public class ChannelClient {
    public static void main(String[] args) {
        try {
            SocketChannel sc = SocketChannel.open();
            sc.configureBlocking(false);
            InetSocketAddress addr = new InetSocketAddress("localhost", 9999);
            // If the connection is established immediately,
            // as can happen with a local connection, then
            // connect() returns true
            sc.connect(addr);
            // otherwise it returns false

            // finishConnect():
            // If this channel is already connected then this method will not block
            // and return true.
            // If this channel is in non-blocking mode then this method will
            // return false if the connection process is not yet complete.
            while (!sc.finishConnect())
                System.out.println("waiting to connect to server...");

            ByteBuffer buffer = ByteBuffer.allocate(10);
            while (sc.read(buffer) >= 0) {
                buffer.flip();
                while (buffer.hasRemaining())
                    System.out.print((char) buffer.get());
                buffer.clear();
            }
            sc.close();
        }
        catch (IOException ioe) {
            System.err.println("I/O error: " + ioe.getMessage());
        }
    }
}