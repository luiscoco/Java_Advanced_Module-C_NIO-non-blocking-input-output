package com.luxoft.nio;

import java.io.IOException;

import java.net.InetSocketAddress;
import java.net.ServerSocket;

import java.nio.ByteBuffer;

import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

import java.util.Iterator;

/**
 * Task: send message from the server with the text "hello from server"
 * Use same selector for accepting and sending the message, for this:
 * 1) register channel for writing after receiving connection;
 * 2) set channel to non-blocking mode by using configureBlocking()
 */
public class SelectorServer {
    final static int DEFAULT_PORT = 9999;

    static ByteBuffer bb = ByteBuffer.allocateDirect(8);

    public static void main(String[] args) throws IOException {
        int port = DEFAULT_PORT;
        System.out.println("Server starting ... listening on port " + port);

        ServerSocketChannel ssc = ServerSocketChannel.open();
        ServerSocket ss = ssc.socket();
        ss.bind(new InetSocketAddress(port));
        ssc.configureBlocking(false);

        Selector s = Selector.open();
        ssc.register(s, SelectionKey.OP_ACCEPT);

        while (true) {
            int n = s.select(); // selecting some channel
            if (n == 0) continue; // nothing was selected
            Iterator it = s.selectedKeys().iterator();
            while (it.hasNext()) {
                SelectionKey key = (SelectionKey) it.next();
                if (key.isAcceptable()) {
                    SocketChannel sc;
                    // non-blocking accept
                    sc = ((ServerSocketChannel) key.channel()).accept();
                    if (sc == null) continue; // no pending connections
                    System.out.println("Receiving connection");
                    bb.clear(); // prepare buffer for writing, set position to 0
                    bb.putLong(System.currentTimeMillis());
                    bb.flip(); // set limit to position, position to 0
                    System.out.println("Writing current time");
                    // write buffer to channel
                    while (bb.hasRemaining()) sc.write(bb);
                    sc.close();
                }
                it.remove(); // remove if communication is done
            }
        }
    }
}