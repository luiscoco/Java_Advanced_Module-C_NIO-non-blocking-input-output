package com.luxoft.nio;

import java.nio.CharBuffer;

public class BufferFlipDemo {
    public static void main(String[] args) {
        String[] poem = {
                        "Roses are red",
                        "Violets are blue",
                        "Sugar is sweet",
                        "And so are you."
                };

        CharBuffer buffer = CharBuffer.allocate(16);

        for (int i = 0; i < poem.length; i++) {
            // Fill the buffer
            for (int j = 0; j < poem[i].length(); j++)
                buffer.put(poem[i].charAt(j));


            System.out.println("Capacity = " + buffer.capacity());
            System.out.println("Limit = " + buffer.limit());
            System.out.println("Position = " + buffer.position());
            System.out.println("Remaining = " + buffer.remaining());
            System.out.println("*** flip() ***");
            // Flip the buffer so that its contents can be read
            buffer.flip();
            System.out.println("Capacity = " + buffer.capacity());
            System.out.println("Limit = " + buffer.limit());
            System.out.println("Position = " + buffer.position());
            System.out.println("Remaining = " + buffer.remaining());
            System.out.println("*************");

            // flip():
            // 1) set limit to position (to keep how much data is in buf)
            // 2) set position to 0 to start reading
            // same as buffer.limit(buffer.position()).position(0);


            // Drain the buffer
            while (buffer.hasRemaining())
                System.out.print(buffer.get());
            System.out.println("\n*************");

            System.out.println("Capacity = " + buffer.capacity());
            System.out.println("Limit = " + buffer.limit());
            System.out.println("Position = " + buffer.position());
            System.out.println("Remaining = " + buffer.remaining());
            // Empty the buffer to prevent BufferOverflowException
            // The position is set to zero,
            // the limit is set to the capacity
            buffer.clear();
            System.out.println("*** clear() ***");
            System.out.println("Capacity = " + buffer.capacity());
            System.out.println("Limit = " + buffer.limit());
            System.out.println("Position = " + buffer.position());
            System.out.println("Remaining = " + buffer.remaining());

            System.out.println();
        }
    }
}