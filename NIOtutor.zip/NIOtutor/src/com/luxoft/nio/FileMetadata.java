package com.luxoft.nio;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.PosixFileAttributeView;
import java.nio.file.attribute.PosixFileAttributes;
import java.util.Set;

public class FileMetadata {

    public static void main(String[] args) throws IOException {
        // supported views
        FileSystem fs = FileSystems.getDefault();
        Set<String> views = fs.supportedFileAttributeViews();

        for (String view : views) {
            System.out.println(view);
        }

        // read basic attributes

        BasicFileAttributes attr = null;
        PosixFileAttributeView posixFileAttributeView = null;

        Path path = Paths.get(".");
        System.out.println(path.toAbsolutePath());
        // read posix attributes
        PosixFileAttributes posixFileAttributes = Files.readAttributes(path, PosixFileAttributes.class);
        posixFileAttributes.permissions().forEach(System.out::println);
        System.out.println(posixFileAttributes.owner().getName());

        try {
            attr = Files.readAttributes(path, BasicFileAttributes.class);
        } catch (IOException e) {
            System.err.println(e);
        }

        System.out.println("File size: " + attr.size());
        System.out.println("File creation time: " + attr.creationTime());
        System.out.println("File was last accessed at: " + attr.lastAccessTime());
        System.out.println("File was last modified at: " + attr.lastModifiedTime());

        System.out.println("Is directory? " + attr.isDirectory());
        System.out.println("Is regular file? " + attr.isRegularFile());
        System.out.println("Is symbolic link? " + attr.isSymbolicLink());
        System.out.println("Is other? " + attr.isOther());
    }

}
