package com.luxoft.nio;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.channels.CompletionHandler;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.CompletableFuture;

public class AsyncToCompletableFuture {

    public static void main(String[] args) throws Exception {
        Path path = Paths.get("file.txt");
        AsynchronousFileChannel ch = AsynchronousFileChannel.open(path);
        final ByteBuffer buffer = ByteBuffer.allocate(1024);

        CompletableFuture<String> completableFuture = new CompletableFuture<>();

        ch.read(buffer, 0, null,
                new CompletionHandler<Integer, Void>() {
                    @Override
                    public void completed(Integer result, Void attachment) {
                        String message = new String(buffer.array(),0,result);
                        completableFuture.complete(message);
                    }
                    @Override
                    public void failed(Throwable t, Void attachment) {
                        completableFuture.completeExceptionally(t);
                    }
                });

        CompletableFuture<Void> future = completableFuture
                .thenAccept(s -> System.out.println(s))
                .thenRun(() -> {
                    try {
                        ch.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });

        //  do something
        System.out.println("do something...");

        future.get();
        System.out.println("End of program");
    }
}
