package com.luxoft.nio;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.util.Date;

public class SelectorClient1
{
    final static int DEFAULT_PORT = 9999;

    static ByteBuffer buffer = ByteBuffer.allocateDirect(100);

    public static void main(String[] args) {
        int port = DEFAULT_PORT;

        try {
            SocketChannel sc = SocketChannel.open();
            InetSocketAddress addr = new InetSocketAddress("localhost", port);
            sc.connect(addr);

            sc.read(buffer); // assume that channel data will fit the buffer
            // prepare buffer for reading
            buffer.flip();

            // convert ByteBuffer to String
            byte[] bytes;
            bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
            String message =  new String(bytes);

            System.out.println(message);

            sc.close();
        } catch (IOException ioe) {
            System.err.println("I/O error: " + ioe.getMessage());
        }
    }
}